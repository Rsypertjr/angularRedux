//app/actions/index.ts
import {UserActions} from './user';

export {
    UserActions
};

export default [
    UserActions
];